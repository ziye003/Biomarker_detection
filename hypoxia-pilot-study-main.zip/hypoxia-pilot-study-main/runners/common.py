import asyncio
import os
import sys

from prefect import flow
from prefect_databricks import DatabricksCredentials
from prefect_databricks.flows import jobs_runs_wait_for_completion
from prefect_databricks.jobs import jobs_run_now


@flow
async def _run_job_until_completion(
    job_id,
    databricks_credentials,
    notebook_params,
):
    job_result = await jobs_run_now(
        databricks_credentials,
        job_id,
        notebook_params=notebook_params,
    )

    print(job_result['run_id'])  # noqa: WPS421

    return await jobs_runs_wait_for_completion(
        job_result['run_id'],
        databricks_credentials,
        max_wait_seconds=360 * 60,  # noqa: WPS432
        poll_frequency_seconds=2 * 60,
    )


def run_and_wait_or_fail(job_id, notebook_params):
    databricks_credentials = DatabricksCredentials(
        databricks_instance=os.environ['DATABRICKS_HOST'],
        token=os.environ['DATABRICKS_TOKEN'],
    )
    task = _run_job_until_completion(
        job_id,
        databricks_credentials,
        notebook_params,
    )
    job_run_state, _ = asyncio.run(task)
    if job_run_state['result_state'] == 'SUCCESS':
        print('Complete')  # noqa: WPS421
        sys.exit(0)
    else:
        print('Failed: job run state', job_run_state)  # noqa: WPS421
        sys.exit(1)

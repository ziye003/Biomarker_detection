import json
import logging
import os
import sys
from datetime import datetime

import boto3
from botocore.client import BaseClient
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.jobs import BaseRun
from pydantic import BaseModel
from pytz import timezone

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',  # noqa: WPS323
    handlers=[logging.StreamHandler(sys.stdout)],
)


logger = logging.getLogger()


class DatabricksRunExporter(BaseModel):
    client: WorkspaceClient
    run_id: str
    s3_client: BaseClient
    timestamp: str

    class Config:  # noqa: WPS306,WPS431
        arbitrary_types_allowed = True

    @classmethod
    def from_credentials(
        cls,
        host: str,
        token: str,
        run_id: str,
    ) -> 'DatabricksRunExporter':
        timestamp = (
            datetime.now().astimezone(timezone('US/Pacific')).strftime('%y%m%d-%H%M')
        )
        logger.info(f'Starting export of run {run_id}')
        return cls(
            client=WorkspaceClient(
                host=host,
                token=token,
            ),
            run_id=run_id,
            s3_client=boto3.client('s3'),
            timestamp=timestamp,
        )

    @property
    def run_metadata(self) -> BaseRun:
        logger.info(f'Finding run {self.run_id} info')
        return self.client.jobs.get_run(self.run_id)

    def export_run_metadata(self) -> None:
        run_metadata = self._format_run_metadata()
        logger.info('Exporting run metadata...')
        self.save_to_s3(run_metadata, 'metadata.json')

    def export_run_tasks(self) -> None:
        for task in self.run_metadata.tasks:
            task_outputs = self.client.jobs.export_run(task.run_id).views

            for task_output in task_outputs:
                logging.info(f'Exporting task {task.run_id} : {task_output.name}')
                filename = f'{task_output.name}.html'
                self.save_to_s3(task_output.content, filename)

    def save_to_s3(self, data_to_export: str, filename: str):
        self.s3_client.put_object(
            Body=data_to_export,
            Bucket=f'sapbio-client-prod-{os.environ["PROJECT_NAME"]}',
            Key=f'04_data_analysis/databricks_job_runs/{self.timestamp}/{filename}',  # noqa: E501
        )

    def _format_run_metadata(self) -> str:
        return json.dumps(
            self.run_metadata.as_dict(),
            sort_keys=True,
            indent=4,
        )


if __name__ == '__main__':
    exporter = DatabricksRunExporter.from_credentials(
        host=os.environ['DATABRICKS_HOST'],
        token=os.environ['DATABRICKS_TOKEN'],
        run_id=os.environ['RUN_ID'],
    )

    exporter.export_run_metadata()

    exporter.export_run_tasks()

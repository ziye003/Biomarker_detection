import os

from runners import common

notebook_params = {
    'project_name': os.environ['PROJECT_NAME'],
}

main_job_id = os.environ['JOB_ID']

if __name__ == '__main__':
    common.run_and_wait_or_fail(main_job_id, notebook_params)

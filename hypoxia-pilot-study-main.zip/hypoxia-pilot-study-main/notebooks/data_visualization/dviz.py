# Databricks notebook source
# MAGIC %run ../initialization/notebook_setup_plotting

# COMMAND ----------

grand_df = (
    DataFileReader(
        file_path='s3://hypoxia-pilot-study/04_data_analysis/grand_table/grand_serum_raw.csv'
    )
    .load()
    .assign(Visit=lambda row: row['Visit'].str.replace(' ', ''))
)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Dot plots with median lines

# COMMAND ----------


def load_raw_data(grand_df, group, timepoint):
    grand_query = grand_df.query(f'(`Treatment ID` == "{group}")').query(
        f'Visit == "{timepoint}"'
    )

    serum_cols = [col for col in grand_query.columns if 'serum' in col]

    grand_melt = grand_query.melt(
        id_vars=['animal', 'Visit', 'Treatment', 'Progressive'],
        value_vars=serum_cols,
        var_name="metabolite",
        value_name="level",
    )

    grand_melt['level'] = grand_melt['level'].fillna(0)

    return grand_melt


# COMMAND ----------


def draw_dot_median_line_plots(timepoint):
    res_file = f'/dbfs/mnt/hypoxia-pilot-study/04_data_analysis/results/serum_placebo_ttest_{timepoint}.csv'
    res = pd.read_csv(res_file)

    grand_raw = load_raw_data(grand_df, 'T01', timepoint)
    sig_metab = res.sort_values('p.value')['metabolite'].tolist()[:3]  # noqa: F841
    grand_raw_selected = grand_raw.query('metabolite in @sig_metab')
    grand_raw_selected['Progressive'] = grand_raw_selected['Progressive'].astype('str')

    print(f'Timepoint = {timepoint}')
    display(res.sort_values('p.value'))
    dplot = DotPlot(grand_raw_selected.fillna(0))  # noqa: F821
    p = dplot.draw(
        ncol=3,
        x='Progressive',
        fig_size=(10, 3.5),
        strip_text_size=10.5,
        x_axis_text_size=10,
        y_axis_text_size=10,
        group_names=["Non-progressive", "Progressive"],
        custom_colors={"0": "#DEB4B2", "1": "#313342"},
    )

    return p


# COMMAND ----------

draw_dot_median_line_plots('Day0')

# COMMAND ----------

draw_dot_median_line_plots('Day168')

# COMMAND ----------

draw_dot_median_line_plots('Day336')

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Line plots for treatment groups

# COMMAND ----------


def load_raw_data_paired(grand_df, group, timepoint):
    grand_query = grand_df.query(f'(`Treatment ID` == "{group}")').query(
        f'Visit == "{timepoint}" | Visit == "Day0"'
    )

    serum_cols = [col for col in grand_query.columns if 'serum' in col]

    grand_melt = grand_query.melt(
        id_vars=['animal', 'Visit', 'Treatment', 'Progressive'],
        value_vars=serum_cols,
        var_name="metabolite",
        value_name="level",
    )
    grand_melt['level'] = grand_melt['level'].fillna(0)

    return grand_melt


# COMMAND ----------


def draw_line_plots_paired(timepoint):
    res_file = f'/dbfs/mnt/hypoxia-pilot-study/04_data_analysis/results/serum_treatment_independent_ttest_Day0vs{timepoint}.csv'
    res = pd.read_csv(res_file)

    res_paired = load_raw_data_paired(grand_df, 'T03', timepoint)
    sig_metab = res.sort_values('p.value')['metabolite'].tolist()[:6]  # noqa: F841
    res_paired_selected = res_paired.query('metabolite in @sig_metab')

    print(f'timepoint = {timepoint}')
    res.sort_values('p.value').display()
    pllot = PairedLinePlot(res_paired_selected)  # noqa: F821
    p = pllot.draw()
    return p


# COMMAND ----------

draw_line_plots_paired('Day168')

# COMMAND ----------

draw_line_plots_paired('Day336')

# Databricks notebook source
# MAGIC %run ../initialization/notebook_setup_plotting

# COMMAND ----------

from toolkits.cytokine_utils import *  # noqa: F403

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load

# COMMAND ----------

cytokine_raw = pd.read_excel(
    '/dbfs/mnt/hypoxia-pilot-study/04_data_analysis/cytokine/231129_JDW_IP_Run_hypoxia.xlsx',
    sheet_name='NPQ',
)
cytokine_raw.head()

# COMMAND ----------

NC_raw = (
    pd.read_excel(
        '/dbfs/mnt/hypoxia-pilot-study/04_data_analysis/cytokine/231129_JDW_IP_Run_hypoxia.xlsx',
        sheet_name='QC_OnPlate',
    )
    .filter(regex='NC*')
    .query('TargetName != "mCherry"')
)

NC_raw.head()


# COMMAND ----------

sampleID = pd.read_excel(
    '/dbfs/mnt/chypoxia-pilot-study/04_data_analysis/cytokine/231129_JDW_IP_Run_hypoxia.xlsx',
    sheet_name='Plate_Map',
)

sampleID['Project Sample ID'] = sampleID['Project Sample ID'].str.replace('Hypoxia_', '')
mapper = sampleID.set_index('Alamar Sample ID')['Project Sample ID'].to_dict()
mapper

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## LOD correction

# COMMAND ----------

# OutlierDetector instance
outlier_detector = OutlierDetector(NC_raw, index_col="TargetName")  # noqa: F405

# LODCalculator instance
lod_calculator = LODCalculator(outlier_detector)  # noqa: F405

# Calculate LOD
lod = lod_calculator.get_LOD(singleplex=False)

# LODCorrector instance
lod_corrector = LODCorrector(cytokine_raw, lod, index_col="targetName")  # noqa: F405

# Get LOD corrected data
lod_corrected_data_LOD = lod_corrector.get_LOD_corrected_data('replace_with_LOD')
# lod_corrected_data_NA = lod_corrector.get_LOD_corrected_data('replace_with_NA')


# COMMAND ----------

lod_corrected_data_LOD

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Replace the alamar ID with the actual sample ID

# COMMAND ----------

lod_corrected_data_LOD.rename(columns=mapper, inplace=True)
lod_corrected_data_LOD.display()

# COMMAND ----------

DataFileWriter.save2files(
    lod_corrected_data_LOD,
    '/dbfs/mnt/hypoxia-pilot-study/04_data_analysis/cytokine/cytokine_lod_corrected.csv',
)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Cytokine preprocessing

# COMMAND ----------

with initialize(version_base=None, config_path="../config"):
    cfg = compose(config_name="config_hypoxia.yaml")
    hypoxia_cytokine = hypoxia_cytokine(cfg)  # noqa: F821, F405
    hypoxia_cytokine.generate_raw_grand_table(save_to_file=True)
    hypoxia_cytokine.load_grand_table(type="raw")
    hypoxia_cytokine.generate_long_format_data(
        spark=spark, raw_data=False, save_to_file=True
    )
    hypoxia_cytokine.generate_long_format_data(
        spark=spark, raw_data=True, save_to_file=True
    )

# COMMAND ----------

# Check results

DataFileReader(
    file_path=hypoxia_cytokine.cfg.files.grand_table_path
    + "grand_cytokine_serum_preprocessed_long.delta"
).load(data_format="delta", spark=spark).display()


DataFileReader(
    file_path=hypoxia_cytokine.cfg.files.grand_table_path
    + "grand_cytokine_serum_raw_long.delta"
).load(data_format="delta", spark=spark).display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Check distributions

# COMMAND ----------

grand = DataFileReader(
    file_path='/dbfs/mnt/_hypoxia-pilot-study/04_data_analysis/grand_table/grand_cytokine_serum_raw.csv'
).load()

# COMMAND ----------

grand.iloc[:, 1:100].hist(bins=50)
plt.gcf().set_size_inches(25, 25)

# COMMAND ----------

grand.iloc[:, 101:200].hist(bins=50)
plt.gcf().set_size_inches(25, 25)

# COMMAND ----------

grand_scaled = DataFileReader(
    file_path='/dbfs/mnt/hypoxia-pilot-study/04_data_analysis/grand_table/grand_cytokine_serum_preprocessed.csv'
).load()

# COMMAND ----------

grand_scaled.iloc[:, 11:100].hist(bins=50)
plt.gcf().set_size_inches(25, 25)

# COMMAND ----------

grand_scaled.iloc[:, 101:].hist(bins=50)
plt.gcf().set_size_inches(25, 25)

import json
import logging
import sys

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s [%(levelname)s] %(message)s',  # noqa: WPS323
    handlers=[logging.StreamHandler(sys.stdout)],
)


logger = logging.getLogger()


class JsonManipulator(object):
    def __init__(self, filename, context_var, new_value):
        self.filename = filename
        self.context_var = context_var
        self.new_value = self._check_for_boolean(new_value)

    def edit_file(self):
        json_dict = self._read()
        original_new_value = json_dict['context']['cookiecutter'][self.context_var]
        logging.info(
            f"""
            Updating file: {self.filename}...
            Replacing the new_value in {self.context_var}...
            Switching from {original_new_value} to {self.new_value}
        """,
        )
        json_dict['context']['cookiecutter'][self.context_var] = self.new_value
        self._write(json_dict)

    @classmethod
    def _check_for_boolean(cls, user_input):
        if user_input in {'True', 'False'}:
            user_input = user_input == 'True'
        return user_input

    def _read(self) -> None:
        with open(self.filename) as json_file:
            json_dict = json.load(json_file)
        return json_dict

    def _write(self, json_dict):
        with open(self.filename, 'w') as json_file:
            json.dump(json_dict, json_file, indent=4, sort_keys=True)


def main():
    json_manipulator = JsonManipulator(
        filename=sys.argv[1],
        context_var=sys.argv[2],
        new_value=sys.argv[3],
    )

    json_manipulator.edit_file()


if __name__ == '__main__':
    main()

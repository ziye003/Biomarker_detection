"""Demonstrate an example module."""


def subtract_numbers(first_number: float, second_number: float):
    return first_number - second_number

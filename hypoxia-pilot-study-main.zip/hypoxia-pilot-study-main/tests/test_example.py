from src.example_module import subtract_numbers


def test_subtract_numbers():
    assert subtract_numbers(10, 4) == 6

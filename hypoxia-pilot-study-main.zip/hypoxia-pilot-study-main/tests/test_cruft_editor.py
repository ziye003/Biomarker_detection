import json

import pytest

from tools import cruft_editor


@pytest.fixture()
def json_dict():
    return {
        'context': {
            'cookiecutter': {
                'key1': 'value1',
                'key2': 'value2',
                'key3': 100,
                'key4': True,
            },
        },
    }


@pytest.fixture()
def json_path(tmp_path):
    return tmp_path / 'test.json'


@pytest.fixture(autouse=True)
def json_file(json_path, json_dict):
    with open(json_path, 'w') as temp_json:
        json.dump(json_dict, temp_json)


@pytest.mark.parametrize(
    'key,newvalue',
    [
        ('key1', 'newvalue'),
        ('key2', 100),
        ('key3', True),
    ],
)
def test_edit_file(json_path, json_dict, key, newvalue):
    editor = cruft_editor.JsonManipulator(
        filename=json_path,
        context_var=key,
        new_value=newvalue,
    )

    editor.edit_file()

    json_dict['context']['cookiecutter'][key] = newvalue

    with open(json_path) as temp_json:
        assert json.load(temp_json) == json_dict


def test_bool_input(json_path, json_dict):
    editor = cruft_editor.JsonManipulator(
        filename=json_path,
        context_var='key1',
        new_value='True',
    )

    editor.edit_file()

    json_dict['context']['cookiecutter']['key1'] = True

    with open(json_path) as temp_json:
        assert json.load(temp_json) == json_dict

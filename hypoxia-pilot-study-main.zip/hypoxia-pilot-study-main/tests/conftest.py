import logging
import os

import boto3
import pytest
from fsspec.config import conf as fsspec_conf
from moto import mock_s3
from moto.server import ThreadedMotoServer


def quiet_py4j() -> None:
    logger = logging.getLogger('py4j')
    logger.setLevel(logging.WARN)


@pytest.fixture(scope='session', autouse=True)
def s3_via_moto_server_mode():
    # Mocked AWS Credentials for moto.
    os.environ['AWS_ACCESS_KEY_ID'] = 'testing'
    os.environ['AWS_SECRET_ACCESS_KEY'] = 'testing'  # noqa: S105
    os.environ['AWS_SECURITY_TOKEN'] = 'testing'  # noqa: S105
    os.environ['AWS_SESSION_TOKEN'] = 'testing'  # noqa: S105
    os.environ['AWS_DEFAULT_REGION'] = 'us-east-1'

    endpoint_port = 5095
    endpoint_url = f'http://localhost:{endpoint_port}'

    fsspec_conf['s3'] = {'client_kwargs': {'endpoint_url': endpoint_url}}

    server = ThreadedMotoServer(port=endpoint_port)
    server.start()

    with mock_s3():
        s3 = boto3.client('s3')
        s3.create_bucket(Bucket='mock_bucket')
        yield s3
    server.stop()

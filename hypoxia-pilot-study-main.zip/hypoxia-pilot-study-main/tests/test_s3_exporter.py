import json
import os
from typing import Any, Dict

import boto3
from botocore.client import BaseClient
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.jobs import (
    BaseRun,
    ExportRunOutput,
    JobsAPI,
    RunTask,
    ViewItem,
)

from runners.export import DatabricksRunExporter

test_job_metadata: Dict[str, Any] = {
    'run_id': '734',
    'tasks': [{'run_id': 1}, {'run_id': 10}, {'run_id': 100}, {'run_id': 1000}],
}
test_job_run_id = test_job_metadata['run_id']
test_task_run_id_list = [task['run_id'] for task in test_job_metadata['tasks']]

mock_html_template = (
    '<head>Header {run_id}</head><body>This is a body <div>divs are great</div></body>'
)

os.environ['RUN_ID'] = test_job_run_id


def decode_bytes(byte_string: bytes) -> str:
    return str(byte_string.decode('UTF-8')).strip()


def test_from_credentials(mocker):
    test_run_exporter = DatabricksRunExporter.from_credentials(  # noqa: S106
        host='databricks',
        token='mock_token',
        run_id=1,
    )

    assert isinstance(test_run_exporter.client, WorkspaceClient)
    assert isinstance(test_run_exporter.s3_client, BaseClient)


def test_list_tasks(mocker):
    client = mocker.MagicMock(WorkspaceClient)
    jobs_api = mocker.MagicMock(JobsAPI)
    client.jobs = jobs_api

    jobs_api.get_run.return_value = BaseRun(
        run_id=test_job_run_id,
        tasks=[RunTask(run_id=index) for index in test_task_run_id_list],
    )

    db_run_exporter = DatabricksRunExporter(
        client=client,
        run_id=test_job_run_id,
        s3_client=boto3.client('s3'),
        timestamp='mock_timestamp',
    )

    jobs_tasks = db_run_exporter.run_metadata.tasks

    assert len(jobs_tasks) == len(test_task_run_id_list)

    assert all(
        task.run_id == run_task_id
        for task, run_task_id in zip(jobs_tasks, test_task_run_id_list)
    )

    jobs_api.get_run.assert_called()


def mocked_s3_put_object(self, data_to_export: str, filename: str) -> None:
    self.s3_client.put_object(
        Body=data_to_export,
        Bucket='mock_bucket',
        Key=filename,
    )


def test_export_job_metadata(mocker):
    client = mocker.MagicMock(WorkspaceClient)
    jobs_api = mocker.MagicMock(JobsAPI)
    client.jobs = jobs_api

    s3_client = boto3.client('s3')

    jobs_api.get_run.return_value = BaseRun(
        run_id=test_job_run_id,
        tasks=[RunTask(run_id=index) for index in test_task_run_id_list],
    )
    mocker.patch.object(DatabricksRunExporter, 'save_to_s3', mocked_s3_put_object)

    db_run_exporter = DatabricksRunExporter(
        client=client,
        run_id=test_job_run_id,
        s3_client=s3_client,
        timestamp='mock_timestamp',
    )
    db_run_exporter.export_run_metadata()

    exported_metadata = s3_client.get_object(
        Bucket='mock_bucket',
        Key='metadata.json',
    )
    metdata_info = exported_metadata['Body'].read()
    metadata_json = json.loads(decode_bytes(metdata_info))

    assert metadata_json == test_job_metadata


def mocked_export_run(run_id: str) -> ExportRunOutput:
    return ExportRunOutput(
        views=[
            ViewItem(
                name=f'notebook_{run_id}',
                content=mock_html_template.format(run_id=run_id),
            ),
        ],
    )


def test_export_notebooks(mocker):
    client = mocker.MagicMock(WorkspaceClient)
    jobs_api = mocker.MagicMock(JobsAPI)
    client.jobs = jobs_api
    s3_client = boto3.client('s3')

    jobs_api.get_run.return_value = BaseRun(
        run_id=test_job_run_id,
        tasks=[RunTask(run_id=index) for index in test_task_run_id_list],
    )
    mocker.patch.object(DatabricksRunExporter, 'save_to_s3', mocked_s3_put_object)
    jobs_api.export_run.side_effect = mocked_export_run

    db_run_exporter = DatabricksRunExporter(
        client=client,
        run_id=test_job_run_id,
        s3_client=s3_client,
        timestamp='mock_timestamp',
    )

    db_run_exporter.export_run_tasks()

    exported_html = [
        s3_client.get_object(
            Bucket='mock_bucket',
            Key=f'notebook_{run_id}.html',
        )
        for run_id in test_task_run_id_list
    ]

    assert len(exported_html) == len(test_task_run_id_list)
    assert all(
        decode_bytes(notebook['Body'].read())
        == mock_html_template.format(run_id=run_id)  # noqa: W503
        for notebook, run_id in zip(exported_html, test_task_run_id_list)
    )
